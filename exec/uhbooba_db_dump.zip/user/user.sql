create table user
(
    id             int auto_increment
        primary key,
    name           varchar(15)  not null,
    password       varchar(255) not null,
    phone          varchar(15)  not null,
    username       varchar(50)  not null,
    mission_status int          not null,
    constraint UK589idila9li6a4arw1t8ht1gx
        unique (phone),
    constraint UKsb8bbouer5wak8vyiiy4pf2bx
        unique (username)
);

INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (1, '차은우', '$2a$10$hdme68VreN8P9rwYqLPzJ.ALZmHO57oROmJVFJM.OLb2jA4ptlZeC', '01011112222', 'woo123', 22);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (2, '뇸뇸이', '$2a$10$kg.xXN5GePH3nT97sQy3h.9ta6rEfO2kjVUCMwZmdHwcJXfK3b3Nu', '476400400106', 'nyomnyom', 0);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (3, '냠냠이', '$2a$10$W1z8D/rfxN7aQC611JYtAOVFWE2WpPaRVilKIZuJXA26nhmRikzkW', '01250460273363', 'nyam', 0);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (4, '이면지', '$2a$10$9Qn2BUf9MXv/pOhYoCnVU.mLqt5IrZTYYoBZoI1tMOTxw8ycFPa6.', '01001011010', 'asdasd1', 15);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (5, '최영빈', '$2a$10$tqDiDREUjF3wJLo8KkuCv.5K1sgRo/oZbJKRDQUqiFnMLkoooZMGy', '01040200840', 'bean', 52);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (6, '호날두', '$2a$10$V1KnppgaYTRh0I3rNPM5ue.Fr.DGaIHmSS/cjmbQACchmBn.Udwrq', '8217968631980', 'siu', 1);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (7, '김지윤', '$2a$10$n8J1m4SJWIc5k/Kt7Zh39.BLq7akYEoB4Lv7SWynOEDHook3yQqbS', '01071379650', 'woo1234', 251);
INSERT INTO uhbooba.user (id, name, password, phone, username, mission_status) VALUES (8, '김인엽', '$2a$10$SZpfbVsHTMAwGKJQu/id4uDB7AUEbJ0itfkNFiGvDpYLVQBC5pzr6', '01023456789', 'yub', 1);
