create table account
(
    id                int auto_increment
        primary key,
    account_name      varchar(255)                                                                             null,
    account_no        varchar(255)                                                                             not null,
    account_type_code enum ('DEMAND_DEPOSIT', 'FIXED_DEPOSIT', 'FOREIGN_DEMAND_DEPOSIT', 'INSTALLMENT_SAVING') not null,
    account_type_name varchar(255)                                                                             null,
    username          varchar(255)                                                                             null,
    user_account_id   int                                                                                      not null,
    balance           bigint                                                                                   null,
    constraint FKiegtfk25hmojqjbea9643r0xj
        foreign key (user_account_id) references user_account (id)
);

create index idx_account_no
    on account (account_no);

INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (1, '싸피은행 수시 입출금 상품', '9999120746805490', 'DEMAND_DEPOSIT', '수시입출금', '차은우', 1, 0);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (2, '한국 전력 공사', '9997917969944682', 'DEMAND_DEPOSIT', null, '한국 전력 공사', 2, 600000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (3, '싸피은행 수시 입출금 상품', '9997084293185124', 'DEMAND_DEPOSIT', '수시입출금', '뇸뇸이', 3, 0);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (5, '싸피은행 수시 입출금 상품', '9993660986301220', 'DEMAND_DEPOSIT', '수시입출금', '이면지', 5, 12087644);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (6, '정기예금 2번 상품', '9992719242', 'FIXED_DEPOSIT', '예금', '냠냠이', 4, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (8, '정기예금 2번 상품', '9993425237', 'FIXED_DEPOSIT', '예금', '냠냠이', 4, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (9, '정기적금 1번 상품', '9995754538', 'INSTALLMENT_SAVING', '적금', '냠냠이', 4, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (11, '정기적금 1번 상품', '9999289124', 'INSTALLMENT_SAVING', '적금', '냠냠이', 4, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (12, '정기적금 1번 상품', '9998318460', 'INSTALLMENT_SAVING', '적금', '냠냠이', 4, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (14, '정기적금 2번 상품', '9996681235', 'INSTALLMENT_SAVING', '적금', '냠냠이', 4, 1000000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (16, '싸피은행 수시 입출금 상품', '9990036070248825', 'DEMAND_DEPOSIT', '수시입출금', '최영빈', 6, 2562993);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (17, '정기예금 1번 상품', '9999865420', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (18, '정기적금 1번 상품', '9998635654', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (19, '정기예금 1번 상품', '9996354686', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (20, '정기예금 1번 상품', '9994154286', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (21, '정기예금 1번 상품', '9993695058', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (22, '정기적금 1번 상품', '9995731814', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (23, '정기적금 1번 상품', '9997681270', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (24, '정기예금 1번 상품', '9996333017', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (25, '정기적금 1번 상품', '9997415959', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (26, '정기적금 1번 상품', '9997744237', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (27, '정기적금 1번 상품', '9995648595', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (28, '정기적금 2번 상품', '9999867330', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (29, '정기적금 1번 상품', '9998486236', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (30, '정기예금 1번 상품', '9997167760', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (31, '정기예금 1번 상품', '9993981403', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (32, '정기적금 1번 상품', '9995818229', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (33, '정기예금 1번 상품', '9994950402', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (34, '정기적금 2번 상품', '9994541487', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (35, '정기예금 1번 상품', '9992514845', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (36, '정기적금 1번 상품', '9999382741', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (37, '정기적금 1번 상품', '9999513459', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (38, '정기적금 1번 상품', '9996986215', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (39, '정기적금 2번 상품', '9992397287', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (40, '정기예금 1번 상품', '9998459515', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (41, '정기적금 2번 상품', '9996625907', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 333333);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (42, '정기적금 3번 상품', '9999213766', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (43, '정기적금 2번 상품', '9994360101', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (44, '정기예금 3번 상품', '9994923510', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 1000000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (45, '정기예금 2번 상품', '9998191577', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (46, '정기예금 1번 상품', '9992471855', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (47, '정기예금 2번 상품', '9998564902', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (48, '정기적금 1번 상품', '9996876452', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 66666);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (49, '정기적금 2번 상품', '9997872081', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 222222);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (50, '정기예금 2번 상품', '9991619664', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (51, '정기예금 1번 상품', '9998924876', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (52, '정기예금 1번 상품', '9991858834', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 111111);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (53, '정기예금 1번 상품', '9992028605', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (54, '정기예금 1번 상품', '9997354531', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 200000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (55, '정기예금 1번 상품', '9998383720', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (56, '싸피은행 수시 입출금 상품', '9993091706201886', 'DEMAND_DEPOSIT', '수시입출금', '김지윤', 8, 53052558);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (57, '정기예금 2번 상품', '9991436952', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 666666);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (58, '정기예금 2번 상품', '9999618873', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (59, '정기예금 2번 상품', '9996270147', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 555555);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (60, '정기적금 2번 상품', '9993175591', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (62, '정기적금 2번 상품', '9994047728', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (64, '싸피은행 수시 입출금 상품', '9999270939424512', 'DEMAND_DEPOSIT', '수시입출금', '호날두', 7, 0);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (66, '정기예금 1번 상품', '9995717675', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (67, '정기예금 1번 상품', '9998245812', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (68, '정기적금 1번 상품', '9992625879', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 333333);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (69, '정기적금 1번 상품', '9997692356', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 333333);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (70, '정기적금 1번 상품', '9997684326', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 333333);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (74, '싸피은행 수시 입출금 상품', '9991403451499820', 'DEMAND_DEPOSIT', '수시입출금', '냠냠이', 4, 9900000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (76, '정기적금 1번 상품', '9998271964', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 22222);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (78, '정기적금 1번 상품', '9995989893', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 22222);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (79, '정기적금 1번 상품', '9997792463', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 33333);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (80, '정기적금 1번 상품', '9996041236', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 33333);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (81, '정기적금 1번 상품', '9999499926', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 44444);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (82, '정기적금 1번 상품', '9992265600', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 44444);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (83, '정기적금 1번 상품', '9991483194', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (85, '정기적금 1번 상품', '9997433111', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 33334);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (87, '정기적금 1번 상품', '9996130646', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 22222);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (89, '정기적금 1번 상품', '9998263813', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (90, '정기적금 1번 상품', '9991718930', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 50000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (91, '정기예금 2번 상품', '9996648709', 'FIXED_DEPOSIT', '예금', '최영빈', 6, 500000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (92, '정기적금 1번 상품', '9997022584', 'INSTALLMENT_SAVING', '적금', '최영빈', 6, 100000);
INSERT INTO uhbooba.account (id, account_name, account_no, account_type_code, account_type_name, username, user_account_id, balance) VALUES (93, '싸피은행 수시 입출금 상품', '9994458609375767', 'DEMAND_DEPOSIT', '수시입출금', '김인엽', 9, 0);
