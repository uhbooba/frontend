create table exchange_account
(
    id            int auto_increment
        primary key,
    balance       bigint       null,
    currency      varchar(255) null,
    exchange_rate varchar(255) null,
    account_id    int          not null,
    constraint FKhfyv6pcgsemuvfg0c80f802qi
        foreign key (account_id) references account (id)
);

INSERT INTO uhbooba.exchange_account (id, balance, currency, exchange_rate, account_id) VALUES (1, 9209260100, 'USD', '1,320.1', 1);
INSERT INTO uhbooba.exchange_account (id, balance, currency, exchange_rate, account_id) VALUES (2, 2060, 'USD', '1,333.3', 56);
