create table deposit_product
(
    id                       int auto_increment
        primary key,
    account_description      varchar(255) null,
    account_name             varchar(255) null,
    account_type_code        varchar(255) null,
    account_type_name        varchar(255) null,
    account_type_unique_no   varchar(255) null,
    bank_code                varchar(255) null,
    bank_name                varchar(255) null,
    interest_rate            double       null,
    max_subscription_balance bigint       null,
    min_subscription_balance bigint       null,
    rate_description         varchar(255) null,
    subscription_period      varchar(255) null
);

INSERT INTO uhbooba.deposit_product (id, account_description, account_name, account_type_code, account_type_name, account_type_unique_no, bank_code, bank_name, interest_rate, max_subscription_balance, min_subscription_balance, rate_description, subscription_period) VALUES (1, '정기예금 1번 상품입니다.', '정기예금 1번 상품', '2', '예금', '999-2-044456a64d5544', '999', '싸피은행', 7, 10000000, 100000, '이율은 7.0%입니다.', '90');
INSERT INTO uhbooba.deposit_product (id, account_description, account_name, account_type_code, account_type_name, account_type_unique_no, bank_code, bank_name, interest_rate, max_subscription_balance, min_subscription_balance, rate_description, subscription_period) VALUES (2, '정기예금 2번 상품입니다.', '정기예금 2번 상품', '2', '예금', '999-2-4e6efff0d4cf4d', '999', '싸피은행', 10, 10000000, 500000, '이율은 10.0%입니다.', '180');
INSERT INTO uhbooba.deposit_product (id, account_description, account_name, account_type_code, account_type_name, account_type_unique_no, bank_code, bank_name, interest_rate, max_subscription_balance, min_subscription_balance, rate_description, subscription_period) VALUES (3, '정기예금 3번 상품입니다.', '정기예금 3번 상품', '2', '예금', '999-2-6cd82e8cf15746', '999', '싸피은행', 12, 10000000, 1000000, '이율은 12.0%입니다.', '365');
