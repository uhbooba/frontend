create table user_account
(
    id       int auto_increment
        primary key,
    user_id  int          not null,
    user_key varchar(255) not null,
    username varchar(255) null,
    constraint UKlfknfymb41d8dg1ritveg4u7
        unique (user_key),
    constraint UKmy17tf2l7ojod9fu836oxcobn
        unique (user_id)
);

INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (1, 1, '74667eae-4171-45d7-905d-6a62816f15d4', '차은우');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (2, 1000000, '96e80462-9de6-47fe-be87-16c511e3945a', '한국 전력 공사');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (3, 2, '9ba4f895-9992-46fd-a666-b7a4336538a2', '뇸뇸이');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (4, 3, '1a6f025d-d287-4e13-8f9c-0e73a3ed7cb5', '냠냠이');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (5, 4, '924f88d0-dd73-47cc-ae93-8b02037f3e1b', '이면지');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (6, 5, '4f453c11-1583-46d1-b6a3-6b6597805fbd', '최영빈');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (7, 6, '3604b5de-f1fc-4705-939d-d90c630c0c0d', '호날두');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (8, 7, '80301062-d70b-4799-9566-c09b6c419c17', '김지윤');
INSERT INTO uhbooba.user_account (id, user_id, user_key, username) VALUES (9, 8, '2ba66058-3755-44f3-b43d-1f214c360957', '김인엽');
