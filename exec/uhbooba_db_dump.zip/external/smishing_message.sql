create table smishing_message
(
    scenario   varchar(10) not null
        primary key,
    sender     varchar(20) null,
    message    text        null,
    time       varchar(20) null,
    sender_img text        null,
    remain     smallint    null
);

INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('A0000', '010-9801-2324', '엄마, 휴대폰이 고장나서 수리 맡겨놓고 지금 컴터 인터넷 문자 사이트로 문자하고 있는 중이니까 답장줘ㅠㅠ', '오후 8:22', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('A0001', '010-9801-2324', '수리비를 지금 내야하는데 돈이 없어서 30만 원만 아래 계좌로 바로 보내줄 수 있어?', '오후 8:28', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('A0002', '010-9801-2324', '엄마, 휴대폰이 고장나서 수리 맡겨놓고 지금 컴터 인터넷 문자 사이트로 문자하고 있는 중이니까 답장줘ㅠㅠ', '오후 8:22', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('A0011', '010-9801-2324', '수리비를 지금 내야하는데 돈이 없어서 30만 원만 아래 계좌로 바로 보내줄 수 있어?', '오후 8:28', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('A0021_F', '010-9801-2324', '수리비를 지금 내야하는데 돈이 없어서 30만 원만 아래 계좌로 바로 보내줄 수 있어?', '오후 8:28', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('B0000', '010-0208-9712', '[모바일청접장] 김지윤♥차은우  일시 : 10/5(토) 11:00 많이많이 와주세요. https://shorturl.gouEX', '오후 5:50', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('B0001', '010-0208-9712', '[모바일청접장] 김지윤♥차은우  일시 : 10/5(토) 11:00 많이많이 와주세요. https://shorturl.gouEX', '오후 5:50', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('B0002', '010-0208-9712', '나무은행 111-111-11111  축의금은 이쪽으로 부탁드려요', '오후 5:55', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('B0012', '010-0208-9712', '나무은행 111-111-11111  축의금은 이쪽으로 부탁드려요', '오후 5:55', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('B0022_F', '010-0208-9712', '나무은행 111-111-11111  축의금은 이쪽으로 부탁드려요', '오후 5:55', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0000', '010-5261-1881', '[안심택배] 배송 출발  고객님의 물건이 배송을 시작했습니다! 빠르고 안전하게 도착할 수 있도록 최선을 다하겠습니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0001', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 2);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0002', '010-5261-1881', '[안심택배] 배송 출발  고객님의 물건이 배송을 시작했습니다! 빠르고 안전하게 도착할 수 있도록 최선을 다하겠습니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0003', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 2);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0011', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 2);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0013', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 2);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0021_F', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0023_F', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0031', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 2);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('C0033', '010-5261-1881', '[안심택배] 배송 주소 오류  고객님의 상품이 배송 중이나, 주소 확인이 불가능하여 배송이 일시 중단되었습니다.', '오전 9:00', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 2);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('D0000_F', '1588-2187', '축하합니다! 응모하신 임영웅 콘서트 티켓에 당첨되었습니다  티켓 수령을 위해 아래 링크에서 추가 정보를 입력해 주세요.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('E0000', '010-2363-4768', 'S사 상한가 포착! 수익률 보장, 투자 황금 기회!  오늘 정보방 이용해 주신 분들에 한하여 다음주 급등 종목 전달 드립니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('E0001', '010-2363-4768', 'N사는 이차전지 확장팩을 출시하고 북미와 유럽에 진출했습니다. 관련 선택 종목도 저희는 보유중입니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('E0002', '010-2363-4768', 'S사 상한가 포착! 수익률 보장, 투자 황금 기회!  오늘 정보방 이용해 주신 분들에 한하여 다음주 급등 종목 전달 드립니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('E0011', '010-2363-4768', 'N사는 이차전지 확장팩을 출시하고 북미와 유럽에 진출했습니다. 관련 선택 종목도 저희는 보유중입니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 1);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('E0021_F', '010-2363-4768', 'N사는 이차전지 확장팩을 출시하고 북미와 유럽에 진출했습니다. 관련 선택 종목도 저희는 보유중입니다.', '9월 23일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('F0000_F', '031-2246-2924', '귀하에게 민원이 접수되어 통보드립니다. - 수원지방법원 - ', '9월 20일', 'https://s3.youm.me/uhbooba/smishing/somebody.png', 0);
INSERT INTO uhbooba.smishing_message (scenario, sender, message, time, sender_img, remain) VALUES ('G0000_F', '나무은행', '은행 방문없이 전화 상담만으로 빠르고 간편하게 대출이 가능합니다.', '9월 20일', 'https://s3.youm.me/uhbooba/smishing/treebank.png', 0);
