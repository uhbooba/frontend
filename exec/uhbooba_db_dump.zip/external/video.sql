create table video
(
    id          int auto_increment
        primary key,
    keyword     varchar(20)                          null,
    title       varchar(255)                         null,
    url         text                                 null,
    description text                                 null,
    upload_at   date                                 null,
    bring_at    datetime default current_timestamp() null,
    views       int                                  null,
    constraint url
        unique (url) using hash
);

INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (1, '금융위원회', '할머니들의 첫 스마트뱅킹', 'https://www.youtube.com/embed/CJ3F28iEfZs?si=UFUb_tkCE2aPGfKE&nocache=1&rel=0&control=2', '은행 업무를 더욱 편리하게 만든
스마트뱅킹!
하지만 이런 새로운 변화가
일상 속 어려움으로 다가오는 분들이 있답니다.
바로 우리 할머니! 할아버지!!
우리 어르신들의 불편함을
조금이나마 해소해드리고 싶어 만든 영상,
70세 어르신들의 스마트금융 도전기!
[할머니께 스마트금융을 알려드렸다]
그 첫번째 에피소드
\'할머니들의 첫 스마트뱅킹\'을 지금 시작합니다.', '2021-07-17', '2024-09-30 04:29:56', 51611);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (2, '금융위원회', '할머니들의 첫 메신저 송금 (feat. 손자·손녀)', 'https://www.youtube.com/embed/3B5j9q3MGag?si=6HpTkF2m2-FkfbOT?nocache=1&rel=0&control=2', '지난 시간에 배운 \'스마트뱅킹\'으로 
한결 업그레이드된 어르신들의 스마트 금융생활!

이번 시간엔 손자·손녀에게 모바일 메신저로
용돈을 보내는 법을 배워보셨어요!

"계좌번호를 몰라도 돈을 보낼 수 있다구?"
생각보다 더 스마트해진 금융에 깜짝 놀라신 우리 할머님들😊
깨톡 보내듯이 간편하게 송금에 성공하셨답니다!

70세 어르신들의 스마트금융 도전기!
[할머니께 스마트금융을 알려드렸다]

그 두번째 에피소드
\'할머니들의 첫 메신저 송금 (feat. 손자·손녀)\'를 지금 시작합니다.

', '2021-07-27', '2024-09-30 04:29:56', 46145);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (3, '금융위원회', '할머니들의 쌓인 카드포인트 현금화하기 (feat. 어카운트인포)', 'https://www.youtube.com/embed/3L7AaWStQq8?si=_pilP4oiGwt8gr7X?nocache=1&rel=0&control=2', '\'스금알\'과 함께 점점 업그레이드되고 있는 어르신들의 스마트 금융생활! 

우리 할머님들이 언제 만들었는지 기억도 안 나는
은행 계좌와 신용카드 내역을 계좌정보통합관리서비스(어카운트인포)에서 
한눈에 촤라락 보여드렸어요! 

특히 그동안 쌓여왔던 신용카드 포인트를 \'계좌정보통합관리서비스\'를 통해 
한 번에 현금화하는 방법도 알려드렸더니 유독 즐거워하셨답니다!

70세 어르신들의 스마트금융 도전기!
[할머니께 스마트금융을 알려드렸다]

그 세 번째 에피소드
\'할머니들의 쌓인 카드포인트 현금화하기\'를 지금 시작합니다.
', '2021-08-18', '2024-09-30 04:29:56', 19972);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (4, '금융위원회', '스미싱으로부터 나를 지키자 #메신저피싱', 'https://www.youtube.com/embed/Fn84Xpw5IZg?si=h-MPck4SPWzzRpwB?nocache=1&rel=0&control=2', '오래간만에 \'스금알\'로 다시 모인 할머님들!

유독 명절 기간에 기승을 부리는 \'스미싱 범죄\'에 대해서 
파헤쳐 보았어요! 

스마트폰을 통해 피해가 자주 발생하는 스미싱을 사례별로 알아보고 
미리 예방하는 방법부터 피해 발생시 대응하는 방법까지 
쭈욱 알려드렸습니다!  

70세 어르신들의 스마트금융 도전기!
[할머니께 스마트금융을 알려드렸다]

그 네 번째 에피소드
\'스미싱으로부터 나를 지키자\', 지금 시작합니다.
', '2021-09-17', '2024-09-30 04:29:56', 8224);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (5, '금융위원회', '우리 할머니들과 보이스피싱 예방부터 대응까지 싹 파헤쳐보겠습니다', 'https://www.youtube.com/embed/iaBtn6ew_pY?si=LSsmRCFQglqpGCXi?nocache=1&rel=0&control=2', '이번 5화에서는 스마트폰을 이용한 금융범죄 2탄 \'보이스피싱\'에 대해서 
할머니들과 파헤쳐 보았어요!

지난 4화에서 알아본 \'스미싱 범죄\'(*하단 링크)와 함께 
여전히 기승을 부리고 있는 \'보이스피싱\'을 사례별로 알아보고
미리 예방하는 방법부터 피해 발생 시 대응하는 방법까지 
A부터 Z까지 알려드렸습니다!

70세 어르신들의 스마트금융 도전기!
[할머니께 스마트금융을 알려드렸다]

그 다섯 번째 에피소드
\'할머니와 함께 보이스피싱 파헤치기\', 지금 시작합니다.

✔스미싱으로부터 나를 지키자 [할머니께 스마트금융을 알려드렸다] 

', '2021-10-08', '2024-09-30 04:29:56', 15394);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (6, '금융위원회', '할머니들은 금융교육을 어디서 받죠?', 'https://www.youtube.com/embed/wXHHL0DXTug?si=6h9rymZASlOuYznu?nocache=1&rel=0&control=2', '할머니들은 금융교육을 어디서 받죠? [할머니께 스마트금융을 알려드렸다] - EP.6

할머니들에게 스마트금융을 알기 쉽게 알려드리고자 
일상에 필요한 주제로 진행해온 스금알이 
이번 6화를 마지막으로 인사를 드리게 되었습니다 😌

마지막 6화에서는 앞으로 할머니들이 저희 스금알 없이도
일상에서 가족들과 함께 다양한 금융교육을 받아볼 수 있는 
유용한 사이트를 알려드렸는데요!
', '2021-10-20', '2024-09-30 04:29:56', 3617);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (7, '시.금.치', '시니어들의 모바일 금융을 코치해드립니다 - ep.1 모바일뱅킹 활용법', 'https://www.youtube.com/embed/1DkgltNXDXs?si=Wzm1WnJrQX6Kgw2f?nocache=1&rel=0&control=2', '어플 설치부터 은행업무까지 모바일 뱅킹에 익숙하지 않은 시니어들을 위한 모바일뱅킹 활용법', '2023-06-26', '2024-09-30 04:29:56', 1490);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (8, '시.금.치', '시니어들의 모바일 금융을 코치해드립니다 - ep.2 오픈뱅킹 활용법', 'https://www.youtube.com/embed/pGz5vv-wluY?si=1YGa5zJv0GZc-T3L?nocache=1&rel=0&control=2', '이제는 어플 하나로 은행업무를 모두 해결 할 수 있다?! 시간절약! 체력절약! 한 곳에서 모두 처리 할 수 있는 오픈뱅킹', '2023-06-27', '2024-09-30 04:29:56', 316);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (9, '시.금.치', '시니어들의 모바일 금융을 코치해드립니다 - ep.3 계좌정보통합관리 활용법', 'https://www.youtube.com/embed/k8tPGl0b8Mw?si=iIki0SdHnoEz-da9?nocache=1&rel=0&control=2', '나도 모르고 있던 계좌를 찾아드립니다 구석구석 숨겨져 있던 은행계좌,증권 등 조회 한번으로 모두 볼 수 있다', '2023-06-28', '2024-09-30 04:29:56', 503);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (10, 'BNK부산은행', '제1편 이제는 디지털금융이 대세다!', 'https://www.youtube.com/embed/73TJal9b_AA?si=Xt7LFPFwwTyDz5Hu?nocache=1&rel=0&control=2', '제4차 산업혁명으로 정보통신과 금융이 융합되어 디지털금융으로 빠르게 변화하고 있습니다. 스마트폰을 이용한 간편송금, 간편결제 등 편리한 금융거래가 가능한 시대에서 디지털금융은 선택이 아닌 \'필수\'입니다.

제1편에서는 디지털금융이 무엇이고 어떤 장단점이 있는지, 왜 우리 생활에서 꼭 필요한 것인지에 대해 알아보도록 하겠습니다.

1. 디지털금융 이해하기
2. 디지털금융 모르면 손해다
3. 디지털금융으로 스마트한 라이프 즐기기', '2020-04-14', '2024-09-30 04:29:56', 598);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (11, 'BNK부산은행', '제2편 스마트라이프를 위한 앱 다운받기', 'https://www.youtube.com/embed/6SUKBmlKmtM?si=YzeseoICgJN9wiBk?nocache=1&rel=0&control=2', '스마트폰으로 디지털금융을 활용하기 위해서는 금융거래에 필요한 앱을 다운받고 실행해야 합니다.

제2편에서는 스마트폰에 와이파이(Wi-Fi)를 설정하는 방법과 PLAY스토어에서 필요한 앱을 다운 받고 설치하는 방법, 그리고 설치한 앱을 실행하는 방법을 알아보도록 하겠습니다. 

1. 와이파이(Wi-Fi) 설정하기
2. PLAY스토어에서 앱 다운받기
3. 다운받은 앱 실행하기', '2020-04-14', '2024-09-30 04:29:56', 325);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (12, 'BNK부산은행', '제3편 편리하게 스마트폰으로 예약하기', 'https://www.youtube.com/embed/JiKFoTih0bk?si=tRbvL5ziLXsS7RN_?nocache=1&rel=0&control=2', '우리 주변에서 스마트폰을 통해 은행업무를 보는 \'모바일뱅킹\'을 이용하는 사람들이 점차 많아 지고 있습니다. 은행에 가지 않고도 언제 어디서나 편리하고 안전하게 금융거래를 할 수 있다는 것을 알고는 있지만 아직 모바일뱅킹이 무엇인지, 어떻게 하는 것인지 모르시는 분들이 많습니다.

제6편에서는 모바일뱅킹에 대한 이해와 모바일뱅킹 및 온라인결제를 위한 전자금융거래 신청과 공인인증서 발급에 대해 알아보도록 하겠습니다.

1. 모바일뱅킹의 이해
2. 공인인증서 이해하기
3. 모바일뱅킹을 위한 준비하기', '2020-04-14', '2024-09-30 04:29:56', 174);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (13, 'BNK부산은행', '제4편 간편하게 스마트폰으로 결제하기', 'https://www.youtube.com/embed/ZA0zw4T6aU8?si=UwHir25atVnhKaeg?nocache=1&rel=0&control=2', '모바일뱅킹은 스마트폰으로 언제 어디서나 계좌조회, 계좌이체, 금융상품 가입 등 금융거래를 자유롭게 할 수 있는 디지털금융 서비스입니다. 은행 창구거래보다 시간과 공간의 구애를 받지 않고 수수료 할인, 우대금리 혜택 등 은행 창구거래보다 장점이 많아 많은 사람들이 모바일뱅킹으로 금융거래를 하고 있습니다.

제7편에서는 부산은행의 모바일뱅킹앱 가입방법, 공인인증서 발급방법, 계좌조회 및 이체방법에 대해 알아보도록 하겠습니다.

1. 부산은행 모바일뱅킹 앱 다운받기
2. 부산은행 모바일뱅킹 가입하기
3. 부산은행 계좌조회 및 이체하기', '2020-04-14', '2024-09-30 04:29:56', 433);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (14, 'BNK부산은행', '제5편 스마트폰으로 금융사기를 친다고?', 'https://www.youtube.com/embed/gTTWnxrWF68?si=7G4LeywzCiJLDExy?nocache=1&rel=0&control=2', '최근 스마트폰이 보급화 되고 관련 기술이 빠르게 발전하는 만큼 이를 악용한 보이스피싱, 스미싱, 파밍 등 신종 디지털금융사기 피해가 증가하고 있습니다.

제5편에서는 신종 디지털금융사기 유형과 금융사기를 당했을 경우의 대처방법, 그리고 금융사기를 당하지 않기 위한 예방법에 대하여 알아보도록 하겠습니다.

1. 금융사기 유형 알아보기
2. 금융사기 대처하기
3. 금융사기 예방하기', '2020-04-14', '2024-09-30 04:29:56', 187);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (15, 'BNK부산은행', '제6편 스마트폰으로 스마트하게 은행거래하기', 'https://www.youtube.com/embed/HSOpACGXa4Q?si=cBNWMAVoNObQTibV?nocache=1&rel=0&control=2', '우리 주변에서 스마트폰을 통해 은행업무를 보는 \'모바일뱅킹\'을 이용하는 사람들이 점차 많아 지고 있습니다. 은행에 가지 않고도 언제 어디서나 편리하고 안전하게 금융거래를 할 수 있다는 것을 알고는 있지만 아직 모바일뱅킹이 무엇인지, 어떻게 하는 것인지 모르시는 분들이 많습니다.

제6편에서는 모바일뱅킹에 대한 이해와 모바일뱅킹 및 온라인결제를 위한 전자금융거래 신청과 공인인증서 발급에 대해 알아보도록 하겠습니다.

1. 모바일뱅킹의 이해
2. 공인인증서 이해하기
3. 모바일뱅킹을 위한 준비하기', '2020-04-14', '2024-09-30 04:29:56', 350);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (16, 'BNK부산은행', '제7편 스마트폰으로 간편하게 송금하기', 'https://www.youtube.com/embed/ezyIJdC-q9A?si=QOLyoGA1cQKa0-f5?nocache=1&rel=0&control=2', '모바일뱅킹은 스마트폰으로 언제 어디서나 계좌조회, 계좌이체, 금융상품 가입 등 금융거래를 자유롭게 할 수 있는 디지털금융 서비스입니다. 은행 창구거래보다 시간과 공간의 구애를 받지 않고 수수료 할인, 우대금리 혜택 등 은행 창구거래보다 장점이 많아 많은 사람들이 모바일뱅킹으로 금융거래를 하고 있습니다.

제7편에서는 부산은행의 모바일뱅킹앱 가입방법, 공인인증서 발급방법, 계좌조회 및 이체방법에 대해 알아보도록 하겠습니다.

1. 부산은행 모바일뱅킹 앱 다운받기
2. 부산은행 모바일뱅킹 가입하기
3. 부산은행 계좌조회 및 이체하기', '2020-04-14', '2024-09-30 04:29:56', 7072);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (17, 'BNK부산은행', '제8편 스마트폰으로 스마트하게 금융거래하기', 'https://www.youtube.com/embed/9KoJGTwUe5I?si=st_gzZD5Qw8IUjvo?nocache=1&rel=0&control=2', '모바일뱅킹을 이용하면 계좌조회 및 이체 뿐만 아니라 현금출금, 환전, 금융상품 가입 및 대출 등 다양한 금융거래를 할 수 있습니다.

제8편에서는 부산은행 모바일뱅킹 앱에서 ATM출금, 환전, 썸패스 간편결제 이용법에 대해 알아보도록 하겠습니다.

1. 스마트폰으로 ATM에서 현금 출금하기
2. 수수료 우대받고 환전하기
3. 썸패스 간편결제 사용하기', '2020-04-14', '2024-09-30 04:29:56', 551);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (18, 'BNK부산은행', '제9편 스마트폰으로 지로요금 납부하기', 'https://www.youtube.com/embed/_k1VlsKBdMU?si=DWveQgdgtXomhXGW?nocache=1&rel=0&control=2', '지로로 납부하는 전기요금, 가스요금 등의 공과금과 취득세, 등록세, 주민세, 자동차세 등의 지방세를 은행에 방문하지 않고 스마트폰으로 납부할 수 있습니다.

제9편에서는 부산은행 모바일뱅킹을 통해서 지로요금 조회 및 납부, 지방세 납부방법에 대해 알아보도록 하겠습니다.

1. 지방세 조회 및 납부하기
2. 지로요금 조회하기
3. 지로요금 납부하기', '2020-04-14', '2024-09-30 04:29:56', 409);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (19, 'BNK부산은행', '제10편 내 모든 금융정보 한눈에 조회하기', 'https://www.youtube.com/embed/tkIE_AJZ7Dk?si=tdLHmCOj8po7F-XU?nocache=1&rel=0&control=2', '핀테크와 정보기술의 발달로 내 금융거래 정보를 통합적으로 조회하고 관리할 수 있습니다. 내 모든 계좌정보, 카드개설정보, 대출정보 등을 확인하고 잠들어 있는 휴면예금도 찾을 수 있습니다.

제10편에서는 계좌정보통합관리 앱 \'어카운트인포\'를 통해 내 금융거래정보 조회방법과 자동이체 조회 및 변경방법에 대하여 알아보도록 하겠습니다.

1. 계좌정보통합관리 어카운트인포 가입하기
2. 은행계좌, 카드, 보험, 대출, 금융정보 조회하기
3. 자동이체 조회, 변경, 해지하기', '2020-04-14', '2024-09-30 04:29:56', 332);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (20, '디지털배움터', '1. 인터넷 뱅킹 완전 정복', 'https://www.youtube.com/embed/jV-lr5rRop0?si=5CvD7WOf-kTq4Nl6?nocache=1&rel=0&control=2', '어르신 금융교육 (인터넷 뱅킹 완전 정복)', '2022-08-16', '2024-09-30 04:29:56', 587);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (21, '디지털배움터', '2. 모바일 뱅킹의 신세계', 'https://www.youtube.com/embed/PlfbqpNszds?si=FSag8PUFawVc-v2v?nocache=1&rel=0&control=2', '어르신 금융교육(모바일 뱅킹의 신세계)', '2022-08-16', '2024-09-30 04:29:56', 342);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (22, '디지털배움터', '3. 노후가 간편해지는 간편결제 사용법', 'https://www.youtube.com/embed/HRmoVTxvPSw?si=beUFKk1U7pG3K9f5?nocache=1&rel=0&control=2', '어르신 금융교육(노후가 간편해지는 간편결제 사용법)', '2022-08-16', '2024-09-30 04:29:56', 210);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (23, '디지털배움터', '4. 내 연금, 내가 몰라도 인터넷은 안다!', 'https://www.youtube.com/embed/ErOa2CjYMNs?si=9b2USB_BNOUNQnYr?nocache=1&rel=0&control=2', '어르신 금융교육(내 연금, 내가 몰라도 인터넷은 안다!)', '2022-08-16', '2024-09-30 04:29:56', 92);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (24, '디지털배움터', '5. 이제 금융상품은 온라인으로 비교', 'https://www.youtube.com/embed/4aK_g2kMMbk?si=TXjKnztiwWdZK0f1?nocache=1&rel=0&control=2', '어르신 금융교육(이제 금융상품은 온라인으로 비교)', '2022-08-16', '2024-09-30 04:29:56', 168);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (25, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 공과금 납부하는 방법', 'https://www.youtube.com/embed/4YG94b_t2gM?si=kNcM18MPgLRRs80o?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ KB국민인증서 로그인 후 [촬영] 버튼 클릭 → ⑤ 공과금 용지 촬영 → ⑥ 계좌 비밀번호 입력 후 납부 정보 확인 → ⑦ 공과금 납부 완료', '2023-07-20', '2024-09-30 04:29:56', 5443);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (26, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 인터넷뱅킹 장기미사용 이체제한 해제하는 방법', 'https://www.youtube.com/embed/n9OElhGrots?si=sVqIhoG6WlzsNTYb?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ KB국민인증서 로그인 → ⑤ [이체 제한해제] 클릭 → ⑥ 추가 본인 인증 완료 후 간편비밀번호 입력 → ⑦ 장기미사용 이체제한 해제 완료', '2023-07-20', '2024-09-30 04:29:56', 1870);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (27, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 자동이체 등록하는 방법', 'https://www.youtube.com/embed/7pjR4UpdzYg?si=o5sjsTtHzng_mKQJ?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ 약관 전체동의 선택 후 [다음] 클릭 → ⑤ 정보 등록 → ⑥ 추가 본인 인증 완료 후 간편비밀번호 입력 → ⑦ 자동이체 등록 완료', '2023-07-20', '2024-09-30 04:29:56', 4033);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (28, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 자동이체 조회·변경·해지하는 방법', 'https://www.youtube.com/embed/MT88X6OtZ8I?si=p8G6bhpGFE0EBFcf?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ KB국민인증서 로그인 후 계좌번호 선택 → ⑤ 변경할 내용 입력 → ⑥ 추가 본인 인증 완료 후 간편비밀번호 입력 → ⑦ 자동이체 변경 완료', '2023-07-20', '2024-09-30 04:29:56', 4940);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (29, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 계좌비밀번호 변경하는 방법', 'https://www.youtube.com/embed/zowPxgY3328?si=JJ3R0SLkH0awNwGS?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ KB국민인증서 로그인 후 계좌번호 선택 → ⑤ 변경할 계좌 입력 → ⑥ 본인 인증 완료 후 간편비밀번호 입력 → ⑦ 계좌비밀번호 변경 완료', '2023-07-20', '2024-09-30 04:29:56', 4682);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (30, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 계좌비밀번호 오류해제하는 방법', 'https://www.youtube.com/embed/oJFrfH6_9EA?si=jdIIKqsAmVkuCBNL?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ KB국민인증서 로그인 후 계좌번호 선택 → ⑤ 기존 계좌 비밀번호 입력 → ⑥ 계좌 비밀번호 오류해제 완료', '2023-07-20', '2024-09-30 04:29:56', 8456);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (31, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 인터넷뱅킹 이체한도 변경하는 방법', 'https://www.youtube.com/embed/QavqaCQ_kJM?si=2H22tdapXgLC7l3D?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ KB국민인증서 로그인 → ⑤ 이체한도 변경 선택 → ⑥ 약관 전체동의 선택  후 신분증 인증 → ⑦ 이체한도 변경 완료', '2023-07-20', '2024-09-30 04:29:56', 9604);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (32, 'KB스타뱅킹', '스타뱅킹을 통해 쉽고 빠르게 모바일인증서 발급하는 방법', 'https://www.youtube.com/embed/Ru2Iz97akR4?si=Dv4hpvR_jUeOhrGk?nocache=1&rel=0&control=2', '📱 이용 방법
①휴대폰에서 [카메라 앱] 클릭 → ②QR코드를 찍고 [인터넷주소] 접속 → ③ KB스타뱅킹 화면으로 이동 → ④ 인증서 발급하기 클릭 → ⑤ 약관 전체동의 후 추가 정보 입력 → ⑥ 신분증 확인 → ⑦ 모바일인증서 발급 완료', '2023-07-20', '2024-09-30 04:29:56', 8711);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (33, '복지관TV', '키오스크 사용법', 'https://www.youtube.com/embed/209ZxvWINfE?si=WpYx5L8bLpxUqxqa?nocache=1&rel=0&control=2', '서민금융진흥원과 함께 하는 시니어디지털금융교육 - 키오스크 : 식권 키오스크, 프랜차이즈 키오스크
식권 키오스크 : 메뉴, 옵션, 결제 순
프랜차이즈 키오스크 : 메뉴/매장, 옵션, 확인, 결제 순
데기번호 확인, 문자알림 신청', '2019-10-20', '2024-09-30 04:29:56', 7366);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (34, '복지관TV', '간편결제의 모든 것 : 네이버페이, 제로페이', 'https://www.youtube.com/embed/Tkw1BHCvnbs?si=lLBv-G3R1SpEWiAX?nocache=1&rel=0&control=2', '서민금융진흥원과 함께 하는 시니어디지털금융교육 - 간편결제의 모든 것 : 네이버페이, 제로페이', '2019-11-29', '2024-09-30 04:29:56', 281);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (35, '복지관TV', '모바일 뱅킹 : 카카오뱅크', 'https://www.youtube.com/embed/YciNPchDHg8?si=WTZVT9cDSOYIwcvj?nocache=1&rel=0&control=2', '서민금융진흥원과 함께 하는 시니어디지털금융교육 - 시니어를 위한 모바일 뱅킹 : 카카오뱅크', '2019-12-04', '2024-09-30 04:29:56', 349);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (36, '복지관TV', '연금제도의 모든 것', 'https://www.youtube.com/embed/95CeicRrbz8?si=EbPuA1HVfIJUrw8Y?nocache=1&rel=0&control=2', '서민금융진흥원과 함께 하는 시니어디지털금융교육 - 연금제도의 모든 것', '2019-12-04', '2024-09-30 04:29:56', 156);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (37, '복지관TV', '디지털금융사기예방', 'https://www.youtube.com/embed/ieehT5IwW3Y?si=-IEnXYex1bKkc30r?nocache=1&rel=0&control=2', '서민금융진흥원과 함께 하는 시니어디지털금융교육 - 시니어를 위한 디지털금융사기예방', '2019-12-04', '2024-09-30 04:29:56', 671);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (38, '서민금융진흥원', '1. 세상의 변화를 알아야 노후준비 할 수 있다', 'https://www.youtube.com/embed/zJyfA9aGOdM?si=DC0EFjIwDhPhZ2Pm?nocache=1&rel=0&control=2', '시니어1 세상의 변화를 알아야 노후준비 할 수 있다', '2020-12-29', '2024-09-30 04:31:12', 198);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (39, '서민금융진흥원', '2. 노후, 돈만 있으면 행복할까 노후기 필요 요소', 'https://www.youtube.com/embed/DSh54HiV0E0?si=sX-KelzD3TDjukq-?nocache=1&rel=0&control=2', '시니어2 노후, 돈만 있으면 행복할까 노후기 필요 요소', '2020-12-29', '2024-09-30 04:31:12', 78);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (40, '서민금융진흥원', '3. 노후엔 얼마가 필요할까', 'https://www.youtube.com/embed/JoksiivgjiA?si=ToQw0z1CfRrIf7kF?nocache=1&rel=0&control=2', '시니어3 노후엔 얼마가 필요할까', '2020-12-29', '2024-09-30 04:31:12', 65);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (41, '서민금융진흥원', '4. 노후에 받을 수 있는 연금 종류', 'https://www.youtube.com/embed/VtK52fN6nOI?si=gWJXoeHNjOoandYC?nocache=1&rel=0&control=2', '시니어4 노후에 받을 수 있는 연금 종류', '2020-12-29', '2024-09-30 04:31:12', 143);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (42, '서민금융진흥원', '5. 내 노후자금을 점검할 수 있는 사이트 소개', 'https://www.youtube.com/embed/1v0Jm7nUupI?si=GSa_x_5UyznMrNk0?nocache=1&rel=0&control=2', '시니어5 내 노후자금을 점검할 수 있는 사이트 소개', '2020-12-29', '2024-09-30 04:31:12', 54);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (43, '서민금융진흥원', '6. 부족한 노후생활비, 어떻게 채울까', 'https://www.youtube.com/embed/naBR9DEwV_Y?si=pA-YAI5kAKiRXnN_?nocache=1&rel=0&control=2', '시니어6 부족한 노후생활비, 어떻게 채울까', '2020-12-29', '2024-09-30 04:31:12', 2406);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (44, '서민금융진흥원', '7. 부족한 노후 목돈, 어떻게 채울까', 'https://www.youtube.com/embed/5snAC--v-0w?si=1ZTF0uQWCNSrkOOv?nocache=1&rel=0&control=2', '시니어7 부족한 노후 목돈, 어떻게 채울까', '2020-12-29', '2024-09-30 04:31:12', 60);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (45, '서민금융진흥원', '8. 편안한 노후를 위한 지출관리', 'https://www.youtube.com/embed/qAWehlnGMys?si=ySl7Ky1MbsI3Fh8d?nocache=1&rel=0&control=2', '시니어8 편안한 노후를 위한 지출관리', '2020-12-29', '2024-09-30 04:31:12', 32);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (46, '서민금융진흥원', '9. 넉넉한 노후를 위한 지출관리, 지금 시작하자', 'https://www.youtube.com/embed/J3xQM-s4Cc0?si=p2L90MEv4dQhrAws?nocache=1&rel=0&control=2', '시니어9 넉넉한 노후를 위한 지출관리, 지금 시작하자', '2020-12-29', '2024-09-30 04:31:12', 35);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (47, '서민금융진흥원', '10. 노후지원제도 의료,일자리,주거 등', 'https://www.youtube.com/embed/sXTk65EiMQo?si=q2pw5zMNPUOjxsxp?nocache=1&rel=0&control=2', '시니어10 노후지원제도 의료,일자리,주거 등', '2020-12-29', '2024-09-30 04:31:12', 81);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (48, '서민금융진흥원', '11. 한정된 노후자금, 우선순위 정하기', 'https://www.youtube.com/embed/RrnTPy8Ov3g?si=xpVfw3x_-K43yjbv?nocache=1&rel=0&control=2', '시니어11 한정된 노후자금, 우선순위 정하기', '2020-12-29', '2024-09-30 04:31:12', 95);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (49, '서민금융진흥원', '12. 노후기, 현금흐름이 중요하다', 'https://www.youtube.com/embed/ynsZjopsjAs?si=oPhP0Y8Llk4ObFWi?nocache=1&rel=0&control=2', '시니어12 노후기, 현금흐름이 중요하다', '2020-12-29', '2024-09-30 04:31:12', 39);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (50, '서민금융진흥원', '13. 필요한 보장성 보험만 쏙쏙 가져가자', 'https://www.youtube.com/embed/npgUNDeYpR8?si=Rf96C6j2rt0JGFw3?nocache=1&rel=0&control=2', '시니어13 필요한 보장성 보험만 쏙쏙 가져가자', '2020-12-29', '2024-09-30 04:31:12', 109);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (51, '서민금융진흥원', '14. 부담되는 보험료, 해지해도 될까요', 'https://www.youtube.com/embed/1TG1Aun9O9E?si=PaxIkIF_dSCLicah?nocache=1&rel=0&control=2', '시니어14 부담되는 보험료, 해지해도 될까요 (보험 Q&A)', '2020-12-29', '2024-09-30 04:31:12', 43);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (52, '서민금융진흥원', '15. 노후 자산관리, 이것만은 꼭', 'https://www.youtube.com/embed/B1XJ9LPeRGA?si=rbgv91N6hfA-UV64?nocache=1&rel=0&control=2', '시니어15 노후 자산관리, 이것만은 꼭', '2020-12-29', '2024-09-30 04:31:12', 318);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (53, '서민금융진흥원', '16. 소득이 있으면 국민연금 적게 받나요', 'https://www.youtube.com/embed/8ofGj4Eyn3U?si=-3zTN02Y8u00_pBn?nocache=1&rel=0&control=2', '시니어16 소득이 있으면 국민연금 적게 받나요 (연금Q&A 1부)', '2020-12-29', '2024-09-30 04:31:12', 318);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (54, '서민금융진흥원', '17. 주택연금, 이사가야 하나요', 'https://www.youtube.com/embed/XqH1G8bZST4?si=YDXqmh_tOnQLUSP2?nocache=1&rel=0&control=2', '시니어17 주택연금, 이사가야 하나요 (연금Q&A 2부)', '2020-12-29', '2024-09-30 04:31:12', 198);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (55, '서민금융진흥원', '18. 상속을 할까, 증여를 할까', 'https://www.youtube.com/embed/VseNKXABosU?si=EcMgh6XqJjwLSjnL?nocache=1&rel=0&control=2', '시니어18 상속을 할까, 증여를 할까', '2020-12-29', '2024-09-30 04:31:12', 137);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (56, '신용카드재단', '1. 위젯 설정하기', 'https://www.youtube.com/embed/61zzS1JpKDE?si=STRx1ZhrB58-E12i?nocache=1&rel=0&control=2', '스마트폰에서 내가 자주 사용하는 앱을
바탕화면에 꺼내 놓아 편리하게 사용할 수 있는 #위젯

이름부터 어려운 \'위젯\' 설정법도
천천히 따라해보면 할 수 있을 거에요!', '2023-07-31', '2024-09-30 04:31:12', 124);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (57, '신용카드재단', '2. 앱 설치하기', 'https://www.youtube.com/embed/sCgtC1Y21L8?si=P8sIIRS5lxMQqDtE?nocache=1&rel=0&control=2', '홈쇼핑, 택시, KTX, 식사 배달까지~
나에게 필요한 앱 설치하기! 방법이 궁금하다면?
그냥 따라해 봐요~', '2023-07-31', '2024-09-30 04:31:12', 107);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (58, '신용카드재단', '3. 간편결제', 'https://www.youtube.com/embed/Wl5UCVPVpBA?si=ssD_geKLzbg2SxzA?nocache=1&rel=0&control=2', '온라인쇼핑몰 간편결제!
아름인 금융프렌드 [간편결제 제험 온라인 쇼핑몰] 체험 사이트에서
미리미리 연습해요 🙂', '2023-07-31', '2024-09-30 04:31:12', 154);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (59, '신용카드재단', '4. 개인정보 보호하기', 'https://www.youtube.com/embed/_wGn6Z0uZAs?si=vXpwuT6DIIxqz520?nocache=1&rel=0&control=2', '신용카드, 신분증, 생체 ID, 전화번호, 사진들까지…
스마트폰에는 많은 개인정보가 있기 때문에
스마트폰에서 개인정보를 보호하는 방법을 알아 두는 건 필수!!', '2023-08-01', '2024-09-30 04:31:12', 85);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (60, '신용카드재단', '5. 디지털금융 이해하기', 'https://www.youtube.com/embed/t1B07C7sdpY?si=rJdXfqCwZy8XQMNC?nocache=1&rel=0&control=2', '현금대신 스마트폰으로 결제하거나,
온라인으로 쇼핑을 하고, 키오스크를 사용해봤다면
모두 일상생활에서 #디지털금융 을 경험한 적이 있다는 사실!
오늘은 디지털금융에 대해 조금 더 알기 쉽게 배워봐요~', '2023-08-01', '2024-09-30 04:31:12', 140);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (61, '신용카드재단', '6. 기본 버튼 이해하기', 'https://www.youtube.com/embed/6v6Lnr7S5w0?si=G56rfKk0Bull8-4r?nocache=1&rel=0&control=2', '스마트폰 기본 버튼 사용방법이 갑자기 떠오르지 않을 때?
맨날 익숙하게 쓰던 버튼만 알고 있다면?
영상을 통해 스마트폰 기본 버튼에 대해 배우고
주변 지인, 가족들에게 자랑해 보자구요!', '2023-08-01', '2024-09-30 04:31:12', 67);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (62, '신용카드재단', '7. 인터넷 기능 알기', 'https://www.youtube.com/embed/-Af2U9-Upgc?si=FZI7D96RzvZqvGJ2?nocache=1&rel=0&control=2', '스마트폰에 인터넷을 연결하고 궁금했던걸 검색해본 후
지인들과 검색결과를 주소로 공유하고 싶다고요?
이번 영상만 차근차근 따라해 보세요!
스마트폰 인터넷 기능은 이제 식은 죽 먹기~', '2023-08-02', '2024-09-30 04:31:12', 33);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (63, '신용카드재단', '8. 디지털금융 용어 ①', 'https://www.youtube.com/embed/B8lMtcqpbvE?si=5zXYoBoRr0DSbQ4S?nocache=1&rel=0&control=2', '디지털금융 용어 이해하기 #1탄
오늘은 #회원가입 #본인인증 #로그인 #CVC #씨브이씨 에 대해 알아보겠습니다.

신용카드재단, 신한카드, 피치마켓과 함께 라면 디지털금융 문제 없어요!', '2023-08-02', '2024-09-30 04:31:12', 92);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (64, '신용카드재단', '9. 디지털금융 용어 ②', 'https://www.youtube.com/embed/9DHWi-0IoRI?si=Yw6Q_2soCZyDD-ex?nocache=1&rel=0&control=2', '디지털금융 용어 이해하기 #2탄
이어서 #오픈뱅킹 #적립금 #포인트 #간편결제 #NFC #엔에프씨
#비대면결제 #키오스크 에 대해 알아보겠어요~', '2023-08-02', '2024-09-30 04:31:12', 117);
INSERT INTO uhbooba.video (id, keyword, title, url, description, upload_at, bring_at, views) VALUES (65, '신용카드재단', '10. 공감하며 배우는 디지털금융', 'https://www.youtube.com/embed/x8gkVe1FaLs?si=RfAoo0tsl_Vw82Oe?nocache=1&rel=0&control=2', '디지털금융 용어 이해하기 #2탄
이어서 #오픈뱅킹 #적립금 #포인트 #간편결제 #NFC #엔에프씨
#비대면결제 #키오스크 에 대해 알아보겠어요~', '2023-08-02', '2024-09-30 04:31:12', 404);
