create table smishing_status
(
    id      int auto_increment
        primary key,
    user_id int         not null,
    case_A  varchar(10) null,
    case_B  varchar(10) null,
    case_C  varchar(10) null,
    case_D  varchar(10) null,
    case_E  varchar(10) null,
    case_F  varchar(10) null,
    case_G  varchar(10) null,
    constraint user_id
        unique (user_id)
);

INSERT INTO uhbooba.smishing_status (id, user_id, case_A, case_B, case_C, case_D, case_E, case_F, case_G) VALUES (1, 3, 'A0000', 'B0000', 'C0000', 'D0000_F', 'E0000', 'F0000_F', 'G0000_F');
INSERT INTO uhbooba.smishing_status (id, user_id, case_A, case_B, case_C, case_D, case_E, case_F, case_G) VALUES (2, 1, 'A0021_F', 'B0022_F', 'C0000', 'D0000_F', 'E0000', 'F0000_F', 'G0000_F');
INSERT INTO uhbooba.smishing_status (id, user_id, case_A, case_B, case_C, case_D, case_E, case_F, case_G) VALUES (3, 7, 'A0021_F', 'B0000', 'C0000', 'D0000_F', 'E0000', 'F0000_F', 'G0000_F');
