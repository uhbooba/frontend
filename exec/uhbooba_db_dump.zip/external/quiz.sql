create table quiz
(
    id         int                                  not null
        primary key,
    part       int                                  null,
    topic      varchar(10)                          null,
    number     int                                  null,
    question   text                                 null,
    answer     tinyint(1)                           null,
    comment    text                                 null,
    created_at datetime default current_timestamp() null
);

create index ix_quiz_id
    on quiz (id);

INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (101, 1, '모바일 뱅킹 활용법', 1, '모바일 뱅킹은 스마트폰이나 태블릿 PC를 이용하여 은행 업무를 보는 것을 말한다', 1, '모바일 뱅킹은 스마트 기기를 통해 은행 업무를 처리하는 서비스를 의미합니다', '2024-10-01 15:29:24');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (102, 1, '모바일 뱅킹 활용법', 2, '모바일 뱅킹을 이용하면 은행 영업시간에 구애받지 않고 언제든지 이용할 수 있다', 1, '모바일 뱅킹은 시간과 장소에 제약 없이 이용할 수 있는 것이 가장 큰 장점 중 하나입니다', '2024-10-01 15:29:24');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (103, 1, '모바일 뱅킹 활용법', 3, '모바일 뱅킹으로는 계좌 조회, 송금, 공과금 납부 등 다양한 금융 업무를 처리할 수 있다', 1, '모바일 뱅킹으로 할 수 있는 일은 계좌 조회, 송금, 공과금 납부 외에도 투자, 대출 상환 등 다양합니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (104, 1, '모바일 뱅킹 활용법', 4, '모바일 뱅킹을 이용하면 대출 상환도 가능하다', 1, '대출 상환 역시 모바일 뱅킹으로 간편하게 처리할 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (105, 1, '모바일 뱅킹 활용법', 5, '모바일 뱅킹은 ATM 기기보다 보안성이 떨어진다', 0, '최근 보안 기술이 발전되면서 모바일 뱅킹이 ATM 기기보다 더 높은 수준의 보안을 제공하는 경우가 많으나, 사용자의 주의가 필요합니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (201, 2, '생활 속 금융', 1, '환전은 은행에서만 할 수 있다', 0, '과거에는 은행만 가능했지만, 지금은 환전소, 공항 등에서도 가능합니다. 앱으로도 간편하게 환전할 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (202, 2, '생활 속 금융', 2, '자동이체는 한 번 설정하면 계속 유지되고 해지할 수 없다', 0, '자동이체는 언제든지 해지할 수 있습니다. 은행이나 금융기관에 연락하거나, 모바일 뱅킹으로 해지 신청이 가능합니다.', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (203, 2, '생활 속 금융', 3, '비트코인은 외국에서 발행하는 화폐이다', 0, '비트코인과 같은 가상화폐는 가상자산으로, 특정 국가에서 발행한 화폐가 아닙니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (204, 2, '생활 속 금융', 4, '카카오뱅크는 인터넷전문은행으로 실물 지점이 없다', 1, '카카오뱅크와 같은 인터넷은행은 실물 지점 없이, 온라인으로 모든 금융 서비스를 제공합니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (205, 2, '생활 속 금융', 5, '신용카드를 분실했을 때, 즉시 카드사에 연락하여 카드 사용을 정지해야 한다', 1, '신용카드 분실 시 즉시 카드사에 연락하여 카드 사용을 정지해야 합니다. 다른 사람이 카드를 사용할 수 있기 때문입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (301, 3, '금융사기 주의', 1, '현금 인출기에서 돈을 인출할 때 주변 사람들에게 비밀번호를 누르는 모습을 보이지 않도록 주의해야 한다', 1, '현금 인출기에서 비밀번호를 누를 때는 주변 사람들에게 보이지 않도록 주의해야 합니다. 비밀번호를 알려주면 누군가가 돈을 훔칠 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (302, 3, '금융사기 주의', 2, '전화로 은행 직원이라고 주장하며 비밀번호를 요구하는 경우 알려줘도 괜찮다', 0, '은행에서는 절대 비밀번호를 전화로 물어보지 않습니다. 비밀번호는 본인만 알고 있어야 합니다. 이는 보이스피싱 사기범들의 수법입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (303, 3, '금융사기 주의', 3, '보이스피싱을 당했을 때는 혼자 해결하지 말고 바로 경찰이나 은행에 연락해야 한다', 0, '보이스피싱 피해를 입었다면 즉시 경찰에 신고하고 거래한 은행에 연락하여 지급 정지를 요청해야 합니다. 빠른 신고가 피해를 최소화할 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (304, 3, '금융사기 주의', 4, '가족이나 지인이 갑자기 큰 돈이 필요하다며 도움을 요청하면, 먼저 직접 만나서 확인해야 한다', 1, '가족이나 지인이라고 해도 먼저 직접 만나서 상황을 확인하고 도와주는 것이 좋습니다. 전화나 메시지로만 돈을 요구하는 경우에는 사기일 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (305, 3, '금융사기 주의', 5, '다른 사람에게 계좌 비밀번호, 보안카드, OTP 번호를 알려줘도 괜찮다', 0, '다른 사람이 계좌와 관련된 정보를 요구하면 단호하게 거절하며, 절대 알려줘서는 안 됩니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (401, 4, '기초 금융 상식', 1, '금리는 항상 일정하게 유지된다', 0, '금리는 시장 상황, 물가, 정부 정책 등 다양한 요인에 따라 변동됩니다. \'고정 금리\'로 명시되지 않은 상품의 경우, 상황에 따라 금리가 변동될 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (402, 4, '기초 금융 상식', 2, '신용카드를 많이 쓰면 신용등급이 올라간다', 0, '신용카드를 많이 사용하는 것만으로는 신용등급이 무조건 올라가는 것은 아닙니다. 신용등급은 결제 이력, 대출 상환 이력 등 여러 요소를 종합해 평가됩니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (403, 4, '기초 금융 상식', 3, '체크카드는 내가 가진 돈만큼만 쓸 수 있다', 1, '체크카드는 은행 계좌에 있는 잔액 내에서만 사용 가능하지만, 신용카드는 미리 사용하고 나중에 결제하는 방식입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (404, 4, '기초 금융 상식', 4, '예금은 금리가 높고, 적금은 금리가 낮다', 0, '일반적으로 적금이 예금보다 금리가 높습니다. 적금은 돈을 일정 기간 동안 묶어두는 대신 더 높은 이자를 제공하는 상품입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (405, 4, '기초 금융 상식', 5, '예금은 주로 생활비를 위해 사용하고, 적금은 목돈 마련을 위해 사용한다', 1, '예금은 자유롭게 입출금이 가능하므로 생활비 관리에 적합합니다. 반면 적금은 목표 금액을 정하고 꾸준히 납입하여 목돈을 마련하는 데 좋습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (501, 5, '연금 제도 이해', 1, '국민연금은 국가에서 운영하며, 직장인만 가입해야 하는 의무적인 연금이다', 0, '국민연금은 직장인뿐만 아니라 자영업자, 농어민 등 모든 국민이 가입해야 하는 의무적인 연금입니다. 직장인만 가입하는 것은 아닙니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (502, 5, '연금 제도 이해', 2, '국민연금은 젊을 때 낸 보험료를 나이 들어서 연금으로 받는 제도이다', 1, '국민연금은 매달 급여에서 일정액을 보험료로 납부하고, 일정 연령이 되면 매달 연금으로 받는 제도입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (503, 5, '연금 제도 이해', 3, '퇴직연금은 회사에서 운영하며, 퇴직 후 받을 수 있다', 1, '퇴직연금은 회사와 금융기관이 함께 운영하는 연금 제도입니다. 퇴직하면 그동안 적립된 금액을 연금이나 일시금으로 받을 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (504, 5, '연금 제도 이해', 4, '연금은 노후 생활을 위한 가장 중요한 자산이다', 1, '연금은 노후 소득을 보장해주는 중요한 수단이며, 안정적인 노후 생활을 위해 필수적인 자산입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (505, 5, '연금 제도 이해', 5, '개인연금은 반드시 가입해야 한다', 0, '개인연금은 은행이나 보험사에서 판매하는 상품으로, 자유롭게 가입할 수 있는 연금입니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (601, 6, '상속 및 유산 관리', 1, '상속은 부모님의 재산을 물려받는 것이므로, 반드시 자녀에게만 물려줄 수 있다', 0, '상속은 자녀뿐만 아니라 배우자, 형제자매 등 법정 상속인에게도 재산이 이전될 수 있습니다. 자세한 내용은 관련 제도를 확인해야 합니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (602, 6, '상속 및 유산 관리', 2, '상속받을 때 세금을 낼 필요가 없다', 0, '상속받은 재산에 대해서는 상속세를 내야 합니다. 조건에 따라 세율이 달라지며, 일정 금액을 초과하면 상속세를 납부해야 합니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (603, 6, '상속 및 유산 관리', 3, '유언이 있으면 그에 따라 상속이 진행된다', 1, '유언이 있으면 유언의 내용대로 상속이 진행되는 것이 원칙입니다. 하지만 유언이 법률에 위반되거나 요건을 갖추지 못한 경우에는 유효하지 않을 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (604, 6, '상속 및 유산 관리', 4, '유산은 부모가 남긴 재산을 말한다', 1, '유산은 일반적으로 부모가 남긴 재산을 의미합니다. 넓은 의미로는 모든 종류의 재산을 포함하며, 부동산, 금전, 유가증권 등이 해당될 수 있습니다', '2024-10-01 15:29:25');
INSERT INTO uhbooba.quiz (id, part, topic, number, question, answer, comment, created_at) VALUES (605, 6, '상속 및 유산 관리', 5, '유산 상속을 받으려면 반드시 법원에 가야 한다', 0, '일반적으로 등기소에서 상속등기를 진행하고, 상속인들끼리 재산을 나누는 절차를 거치면 됩니다', '2024-10-01 15:29:25');
